'use strict';

document.addEventListener("DOMContentLoaded", () => {
  const dialog1 = document.querySelector("#dialog1");
  const dialog2 = document.querySelector("#dialog2");
  const openDialogBtn = document.querySelector("#open-dialog");
  const clearBtn = document.querySelector("#clear-cookies");
  const acceptAllBtn = document.querySelector("#accept-all");
  const settingsBtn = document.querySelector("#open-settings");
  const saveBrowser = document.querySelector("#save-browser");
  const saveOS = document.querySelector("#save-os");
  const saveScreen = document.querySelector("#save-screen");
  const saveBtn = document.querySelector("#save-settings");
  const cancelBtn = document.querySelector("#cancel-settings");
  const cookieEnabledTxt = document.querySelector("#cookie-enabled-text");
  const browserTxt = document.querySelector("#browser-text");
  const osTxt = document.querySelector("#os-text");
  const screenTxt = document.querySelector("#screen-text");

  const COOKIE_TIME = 1000; 
  
  function setCookie(name, value, seconds) {
    const d = new Date();
    d.setTime(d.getTime() + seconds * 1000); 
    document.cookie = name + "=" + value + "; expires=" + d.toUTCString() + "; path=/";
  }

  function getCookie(name) {
    const parts = document.cookie.split(";");
    for (let i = 0; i < parts.length; i++) {
      const item = parts[i].trim().split("=");   
      if (item[0] === name) return item[1];
    }
    return null;
  }

  function deleteCookie(name) {
    document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; Max-Age=0; path=/";
  }

  function getBrowser() {
    const ua = navigator.userAgent;
    if (ua.includes("Firefox")) return "Firefox";
    if (ua.includes("Edg")) return "Edge"; 
    if (ua.includes("Chrome") && !ua.includes("Edg")) return "Chrome"; 
    if (ua.includes("Safari")) return "Safari";
    return "Unknown";
  }

  function getOS() {
    const ua = navigator.userAgent;
    if (ua.includes("Win")) return "Windows";
    if (ua.includes("Mac")) return "MacOS";
    if (ua.includes("Linux")) return "Linux";
    if (ua.includes("Android")) return "Android";
    if (ua.includes("iPhone") || ua.includes("iPad")) return "iOS";
    return "Unknown";
  }
  
  function updateInfo() {
    cookieEnabledTxt.textContent = "Cookies Enabled: " + navigator.cookieEnabled;
    
    browserTxt.textContent = getCookie("browser") || "Not Stored (" + getBrowser() + ")";
    osTxt.textContent = getCookie("os") || "Not Stored (" + getOS() + ")";
    screenTxt.textContent = getCookie("screen") || "Not Stored (" + screen.width + "x" + screen.height + ")";
  }

  function checkConsent() {
    const consent = getCookie("consentCookie");
    
    if (consent === null) {
      setTimeout(() => {
        dialog1.showModal(); 
      }, 700);
    }
  }
  
  openDialogBtn.addEventListener("click", () => {
    dialog1.showModal();
  });

  acceptAllBtn.addEventListener("click", () => {
    setCookie("consentCookie", "yes", COOKIE_TIME);
    setCookie("browser", getBrowser(), COOKIE_TIME);
    setCookie("os", getOS(), COOKIE_TIME);
    setCookie("screen", screen.width + "x" + screen.height, COOKIE_TIME);

    dialog1.close();
    updateInfo(); 
  });

  settingsBtn.addEventListener("click", () => {
    dialog1.close();
    dialog2.showModal();
  });

  saveBtn.addEventListener("click", () => {
    setCookie("consentCookie", "set", COOKIE_TIME); 

    deleteCookie("browser");
    deleteCookie("os");
    deleteCookie("screen");

    if (saveBrowser.checked) {
      setCookie("browser", getBrowser(), COOKIE_TIME);
    }
    if (saveOS.checked) {
      setCookie("os", getOS(), COOKIE_TIME);
    }
    if (saveScreen.checked) {
      setCookie("screen", screen.width + "x" + screen.height, COOKIE_TIME);
    }

    dialog2.close();
    updateInfo();
  });

  cancelBtn.addEventListener("click", () => {
    dialog2.close();
    dialog1.showModal(); 
  });

  clearBtn.addEventListener("click", () => {
    deleteCookie("consentCookie");
    deleteCookie("browser");
    deleteCookie("os");
    deleteCookie("screen");
    alert("Cookies have been cleared. Please refresh the page.");
    updateInfo();
  });

  updateInfo();
  checkConsent();
});